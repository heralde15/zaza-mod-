# Panel Admin v3.1 para terraria-unified (v0.3.3 / Terraria 1.4.5.8)

NO ESTA COMPILADO NI PROBADO (no hay .NET ni los archivos de Terraria donde se escribio).
Si hay errores de compilacion, pegalos y se corrigen.

## Uso (F8, se arrastra por la barra de titulo)
Un jugador: todo local y sin restricciones. En servidor TShock solo Mundo/Jugador/Items mandan
comandos de chat y TShock decide los permisos.

- Mundo: hora (dia/mediodia/noche/medianoche), congelar hora, fase de luna, lluvia, tormenta de
  arena, luna de sangre, eclipse, fiesta, matar enemigos, meteorito, Hardmode.
- Jugador: godmode (vida/mana/aire + sin debuffs), curar, vida/mana max, volar (WASD) con velocidad
  ajustable, luz.
- Items: por ID o nombre + cantidad, y botones rapidos.
- Jefes: 18 jefes + Muro de Carne + cualquier NPC por ID o nombre.
- Eventos: invasiones goblin/helada/piratas/marcianos, detener invasion.
- Tele: spawn, cama, mazmorra, inframundo, centro, mi posicion, ir a X,Y.
- Todo: revelar mapa, marcar jefes derrotados, quitar debuffs, activar/desactivar todo.

## Instalar
Copia los 3 archivos sobre el repo (solo AdminPanel.cs cambia respecto a la v1), ejecuta
setup.bat / setup-cli.sh y compila con tModLoader.sln.
